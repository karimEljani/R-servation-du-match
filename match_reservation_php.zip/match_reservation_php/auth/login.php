<?php
require_once '../config/database.php';
require_once '../config/auth.php';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = ['id'=>$user['id'], 'name'=>$user['name'], 'email'=>$user['email']];
        header('Location: ../user/dashboard.php');
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin'] = ['id'=>$admin['id'], 'name'=>$admin['name'], 'email'=>$admin['email']];
        header('Location: ../admin/dashboard.php');
        exit;
    }

    $error = "Email ou mot de passe incorrect.";
}
?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Connexion</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="auth-page">
<div class="auth-box">
<a class="brand" href="../index.php">⚽ MatchTicket</a>
<h1>Connexion</h1>
<p>Accédez à votre espace utilisateur ou administrateur.</p>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post">
<label>Email<input type="email" name="email" required></label>
<label>Mot de passe<input type="password" name="password" required></label>
<button class="btn full">Se connecter</button>
</form>
<p>Pas encore de compte ? <a href="register.php">Créer un compte</a></p>
<p><a href="../index.php">← Retour</a></p>
</div>
</body></html>