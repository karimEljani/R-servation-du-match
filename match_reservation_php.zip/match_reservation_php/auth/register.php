<?php
require_once '../config/database.php';
require_once '../config/auth.php';
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $error = "Veuillez remplir correctement les champs.";
    elseif (strlen($password) < 6) $error = "Le mot de passe doit contenir au moins 6 caractères.";
    elseif ($password !== $confirm) $error = "Les mots de passe ne correspondent pas.";
    else {
        $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);
        if ($check->fetch()) $error = "Cet email est déjà utilisé.";
        else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)");
            $stmt->execute([$name,$email,$hash]);
            $success = "Compte créé. Vous pouvez maintenant vous connecter.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Inscription</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body class="auth-page">
<div class="auth-box">
<a class="brand" href="../index.php">⚽ MatchTicket</a>
<h1>Créer un compte</h1>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
<form method="post">
<label>Nom complet<input type="text" name="name" required></label>
<label>Email<input type="email" name="email" required></label>
<label>Mot de passe<input type="password" name="password" required></label>
<label>Confirmer le mot de passe<input type="password" name="confirm_password" required></label>
<button class="btn full">Créer mon compte</button>
</form>
<p>Déjà inscrit ? <a href="login.php">Se connecter</a></p>
</div>
</body></html>