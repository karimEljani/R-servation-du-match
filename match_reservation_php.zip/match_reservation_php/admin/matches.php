<?php
require_once '../config/database.php'; require_once '../config/auth.php'; requireAdmin();
if(isset($_GET['delete'])){$id=(int)$_GET['delete'];$pdo->prepare("DELETE FROM matches WHERE id=?")->execute([$id]);header('Location: matches.php');exit;}
$matches=$pdo->query("SELECT m.*,s.name stadium_name FROM matches m JOIN stadiums s ON s.id=m.stadium_id ORDER BY m.match_date DESC")->fetchAll();
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Matchs - Admin</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><nav class="navbar"><a class="brand" href="dashboard.php">⚽ Admin</a><div><a href="dashboard.php">Dashboard</a><a href="users.php">Utilisateurs</a><a href="reservations.php">Réservations</a><a href="../auth/logout.php">Déconnexion</a></div></nav>
<main class="container"><div class="section-title"><h1>Gestion des matchs</h1><a class="btn" href="add_match.php">+ Ajouter</a></div><div class="card table-wrap"><table><thead><tr><th>Match</th><th>Compétition</th><th>Date</th><th>Stade</th><th>Prix</th><th>Actions</th></tr></thead><tbody>
<?php foreach($matches as $m):?><tr><td><?=e($m['home_team'])?> - <?=e($m['away_team'])?></td><td><?=e($m['competition'])?></td><td><?=date('d/m/Y H:i',strtotime($m['match_date']))?></td><td><?=e($m['stadium_name'])?></td><td><?=number_format((float)$m['price'],2)?> DT</td><td><a href="edit_match.php?id=<?=$m['id']?>">Modifier</a> | <a class="danger-text" onclick="return confirm('Supprimer ce match ?')" href="?delete=<?=$m['id']?>">Supprimer</a></td></tr><?php endforeach;?>
</tbody></table></div></main></body></html>