<?php
require_once '../config/database.php'; require_once '../config/auth.php'; requireAdmin();
$stadiums=$pdo->query("SELECT * FROM stadiums ORDER BY name")->fetchAll();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $home=trim($_POST['home_team']);$away=trim($_POST['away_team']);$competition=trim($_POST['competition']);$date=$_POST['match_date'];$price=(float)$_POST['price'];$stadium=(int)$_POST['stadium_id'];$seats=(int)$_POST['total_seats'];
 if($home===''||$away===''||$date===''||$price<=0||$seats<=0)$error='Veuillez remplir tous les champs correctement.';
 else{$st=$pdo->prepare("INSERT INTO matches(home_team,away_team,competition,match_date,price,stadium_id,total_seats) VALUES(?,?,?,?,?,?,?)");$st->execute([$home,$away,$competition,$date,$price,$stadium,$seats]);header('Location: matches.php');exit;}
}
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ajouter un match</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><main class="container narrow"><div class="card"><h1>Ajouter un match</h1><?php if($error):?><div class="alert error"><?=$error?></div><?php endif;?><form method="post">
<label>Équipe domicile<input name="home_team" required></label><label>Équipe visiteuse<input name="away_team" required></label><label>Compétition<input name="competition" value="Championnat" required></label><label>Date et heure<input type="datetime-local" name="match_date" required></label><label>Prix (DT)<input type="number" step="0.01" name="price" required></label><label>Stade<select name="stadium_id" required><?php foreach($stadiums as $s):?><option value="<?=$s['id']?>"><?=e($s['name'])?></option><?php endforeach;?></select></label><label>Nombre de places<input type="number" name="total_seats" value="1000" required></label><button class="btn">Ajouter</button> <a href="matches.php">Annuler</a></form></div></main></body></html>