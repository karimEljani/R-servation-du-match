<?php
require_once '../config/database.php';
require_once '../config/auth.php';
requireAdmin();
$users=(int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$matches=(int)$pdo->query("SELECT COUNT(*) FROM matches")->fetchColumn();
$res=(int)$pdo->query("SELECT COUNT(*) FROM reservations")->fetchColumn();
$revenue=(float)$pdo->query("SELECT COALESCE(SUM(total_price),0) FROM reservations WHERE status='confirmed'")->fetchColumn();
?>
<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Administration</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body><nav class="navbar admin-nav"><a class="brand" href="dashboard.php">⚽ MatchTicket Admin</a><div><a href="matches.php">Matchs</a><a href="users.php">Utilisateurs</a><a href="reservations.php">Réservations</a><a href="../auth/logout.php">Déconnexion</a></div></nav>
<main class="container"><h1>Tableau de bord</h1><div class="stats"><div class="stat"><span>Utilisateurs</span><strong><?=$users?></strong></div><div class="stat"><span>Matchs</span><strong><?=$matches?></strong></div><div class="stat"><span>Réservations</span><strong><?=$res?></strong></div><div class="stat"><span>Chiffre d'affaires</span><strong><?=number_format($revenue,2)?> DT</strong></div></div>
<div class="card"><h2>Administration</h2><p>Utilisez le menu pour gérer les matchs, utilisateurs et réservations.</p></div></main></body></html>