<?php
declare(strict_types=1);
if (session_status() === PHP_SESSION_NONE) session_start();

function requireLogin(): void {
    if (empty($_SESSION['user'])) {
        header('Location: ../auth/login.php');
        exit;
    }
}

function requireAdmin(): void {
    if (empty($_SESSION['admin'])) {
        header('Location: ../auth/login.php');
        exit;
    }
}

function e(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>